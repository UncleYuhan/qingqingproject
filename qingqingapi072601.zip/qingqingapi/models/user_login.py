from flask import Flask
from mongoengine import *


class userLogin(Document):
    loginAccount = StringField(required = True, unique=True, max_length=255)
    quid = StringField(max_length = 255, unique=True, required = True)
    meta = {'allow_inheritance': True}
