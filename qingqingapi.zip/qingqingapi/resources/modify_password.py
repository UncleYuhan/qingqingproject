from models.user_register import userRegister
from flask_restful import reqparse, Resource
from werkzeug.security import generate_password_hash, check_password_hash
from mongoengine import *


# 修改密码
class modify_password(Resource):
    def get(self):
        pass
    def post(self):
        try:
            # 使用flask-restful获取请求的参数(账号及旧、新密码)
            parser = reqparse.RequestParser()
            parser.add_argument('name', type=str, location='headers', required=True,help="Name cannot be blank!")
            parser.add_argument('oldPsd', type=str, location='headers', required=True,help="OldPassword cannot be blank!")
            parser.add_argument('newPsd', type=str, location='headers', required=True,help="OldPassword cannot be blank!")
            args = parser.parse_args()
            username = args['name']
            oldPassword = args['oldPsd']
            newPassword = args['newPsd']
            # 对新密码加密
            newPsdHsCode = generate_password_hash(newPassword)
            # 获取数据库中对应用户名的HSCODE
            try:
                getHsCode = userRegister.objects(Q(loginAccount=username))[0].psdHsCode
            except IndexError:
                return("账号不存在~")
            # 验证密码
            if check_password_hash(getHsCode, oldPassword):
                # 验证通过后，更新新密码
                userRegister.objects(loginAccount=username).update(psdHsCode=newPsdHsCode)
                return("密码修改成功")
            else:
                # 根据前端需求可调整返回内容
                return("旧密码错误")
        except NotUniqueError:
            return("其他错误？")
