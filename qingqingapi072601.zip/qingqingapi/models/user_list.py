from flask import Flask
from mongoengine import *


class userList(Document):
    quid = StringField(required = True, unique=True, max_length=255)
    userName = StringField(max_length=255, required=True)
    sex = StringField(max_length=100)
    location = StringField(max_length=255)
    age = StringField(max_length=100)
    qqNum = StringField(max_length=100)
    wechatNum = StringField(max_length=100)
    phoneNum = StringField(max_length=100)
    qAuthority = StringField(max_length=100)
    ifVip = StringField(max_length=100)
    vipLevel = StringField(max_length=100)
    userScore = StringField(max_length=100)
    lastLoginTime = StringField(max_length=100)
    imgUrl =  StringField(max_length=255)
    userDetail = StringField(max_length=255)
    userHobby = StringField(max_length=255)
    userJob = StringField(max_length=100)
    userRole = StringField(max_length=100)
    userEmail = StringField(max_length=100)
    meta = {'allow_inheritance': True}
