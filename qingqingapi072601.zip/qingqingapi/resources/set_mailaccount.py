from models.user_list import userList
from models.user_login import userLogin
from models.user_register import userRegister
from flask_restful import reqparse, Resource
import time, random
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from mongoengine import *
from flask import current_app


# 设置密保邮箱
class set_mailaccount(Resource):
    def get(self):
        pass
    def post(self):
        try:
            # 使用flask-restful获取请求的参数(账号、邮箱)
            parser = reqparse.RequestParser()
            parser.add_argument('name', type=str, location='headers', required=True,help="Name cannot be blank!")
            parser.add_argument('email', type=str, location='headers', required=True,help="Email cannot be blank!")
            args = parser.parse_args()
            username = args['name']
            mailaccount = args['email']
            # 获取数据库中对应用户名的HSCODE
            try:
                getUserMail = userList.objects(Q(userName=username))[0].userEmail
            except IndexError:
                return("账号不存在~")
            # 判断用户是否有邮箱
            if getUserMail == '':
                # 用户没有密保邮箱，设置邮箱
                userList.objects(userName=username).update(userEmail=mailaccount)
                return("密保邮箱设置成功")
            else:
                # 根据前端需求可调整返回内容
                return("您已有密保邮箱~可登陆验证后进行修改哦~")
        except NotUniqueError:
            return("其他错误？")
