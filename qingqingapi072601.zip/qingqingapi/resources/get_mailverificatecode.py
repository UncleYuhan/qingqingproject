from models.user_list import userList
from models.user_register import userRegister
from flask_restful import reqparse, Resource
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from mongoengine import *
from flask import current_app
from flask_mail import Mail, Message
import random


mail = Mail()
# 获取邮箱验证码
class get_mailverificatecode(Resource):
    def get(self):
        pass
    def post(self):
        try:
            # 使用flask-restful获取请求的参数(账号)
            parser = reqparse.RequestParser()
            parser.add_argument('name', type=str, location='headers', required=True,help="Name cannot be blank!")
            args = parser.parse_args()
            username = args['name']
            # 判断账号是否存在
            try:
                getHsCode = userRegister.objects(Q(loginAccount=username))[0].psdHsCode
            except IndexError:
                return("账号不存在~")
            # 判断当前用户可用的密保方式
            if userList.objects(Q(userName=username))[0]['userEmail'] == '':
                # ***********如果没有Email，就后续返回个链接让用户设置一个邮箱
                # 后续调整为跳转绑定邮箱（或其他方式）
                return("该用户没有密保邮箱~")
            else:
                # 获取用户邮箱
                recipienter = userList.objects(Q(userName=username))[0]['userEmail']
                # 生成6位验证码
                mailverificationcode = ''.join(random.sample('0123456789',6))
                # 对验证码进行加密
                newMvcodeHsCode = generate_password_hash(mailverificationcode)
                # 更新验证码
                userRegister.objects(loginAccount=username).update(mailVerificateCode=newMvcodeHsCode)
                # 设置邮件标题和收件人
                msg = Message(subject="青青账号安全验证", recipients=[recipienter])
                # 设置邮件内容
                msg.body='敬爱的用户：'+username+'您好！我们已收到您的密码重置申请，请妥善保管，切勿泄露验证码：'+mailverificationcode
                mail.send(msg)
                return("验证码已发送，请注意查收~")
        except NotUniqueError:
            return("其他错误？")