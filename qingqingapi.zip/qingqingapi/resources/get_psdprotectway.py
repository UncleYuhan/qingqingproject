from models.user_list import userList
from models.user_login import userLogin
from models.user_register import userRegister
from flask_restful import reqparse, Resource
import time, random
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from mongoengine import *
from flask import current_app, json


# 获取密保方式
class get_psdprotectway(Resource):
    def get(self):
        pass
    def post(self):
        try:
            # 使用flask-restful获取请求的参数（账号）
            parser = reqparse.RequestParser()
            parser.add_argument('name', type=str, location='headers', required=True,help="Name cannot be blank!")
            args = parser.parse_args()
            username = args['name']
            try:
                getHsCode = userRegister.objects(Q(loginAccount=username))[0].psdHsCode
                # 获取当前用户可用的密保方式
                psdProtectWayList = ['phoneNum','userEmail']
                psdProtectWay = {}
                for i in psdProtectWayList:
                    if userList.objects(Q(userName=username))[0][i] == '':
                        pass
                    else:
                        # 为保安全，需替换字符串中间几位（该处待优化）
                        psdProtectWayValue = userList.objects(Q(userName=username))[0][i]
                        # 计算获取的字符串长度一半取整
                        psdProtectWayValueLen = int(len(psdProtectWayValue)/2)
                        # 替换字符串中间的一版为*
                        psdProtectWay[i] = psdProtectWayValue.replace(psdProtectWayValue[int(psdProtectWayValueLen-psdProtectWayValueLen/2):int(psdProtectWayValueLen+psdProtectWayValueLen/2)],'*'*psdProtectWayValueLen)
                if psdProtectWay != {}:
                    return(json.dumps(psdProtectWay))
                else:
                    # 后续调整为跳转绑定邮箱（或其他方式）
                    return("该用户没有密保方式~")
            except IndexError:
                return("账号不存在~")
        except NotUniqueError:
            return("其他错误？")
