from models.user_list import userList
from models.user_login import userLogin
from models.user_register import userRegister
from flask_restful import reqparse, Resource
import time, random
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from mongoengine import *
from flask import current_app


class reset_password(Resource):
    def get(self):
        pass
    def post(self):
        try:
            # 使用flask-restful获取请求的参数
            parser = reqparse.RequestParser()
            parser.add_argument('name', type=str, location='headers', required=True,help="Name cannot be blank!")
            parser.add_argument('newPsd', type=str, location='headers', required=True,help="NewPassword cannot be blank!")
            parser.add_argument('yzm', type=str, location='headers', required=True,help="mailVerificateCode cannot be blank!")
            args = parser.parse_args()
            username = args['name']
            newPassword = args['newPsd']
            yzm = args['yzm']
            # 获取数据库中对应用户名的HSCODE
            try:
                getmailVerificateCode = userRegister.objects(Q(loginAccount=username))[0].mailVerificateCode
            except IndexError:
                return("账号不存在~")
            # 核对验证码是否正确
            if check_password_hash(getmailVerificateCode, yzm):
                # 验证通过后，更新新密码
                newResetPsdHsCode = generate_password_hash(newPassword)
                userRegister.objects(loginAccount=username).update(psdHsCode=newResetPsdHsCode)
                # 验证通过后，更新新验证码
                mailverificationcode = ''.join(random.sample('0123456789',6))
                newMvcodeHsCode = generate_password_hash(mailverificationcode)
                userRegister.objects(loginAccount=username).update(mailVerificateCode=newMvcodeHsCode)
                return("密码重置成功")
            else:
                # 根据前端需求可调整返回内容
                return("验证码错误")
        except NotUniqueError:
            return("其他错误？")
