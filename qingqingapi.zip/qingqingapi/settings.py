from mongoengine import *
from flask import current_app


class Config(object):
	DEBUG = False
	TESTING = False
	# DATABASE_URL = ''


class MongoDB(Config):
	MONGODB_NAME = 'qingqing01'
	connect(MONGODB_NAME)


class MailMsg(Config):
	current_app.config.update(
	MAIL_SERVER='smtp.qq.com',
	MAIL_PORT='465',
	MAIL_USE_SSL=True,
	MAIL_USERNAME='276309888@qq.com',
	MAIL_DEFAULT_SENDER = '276309888@qq.com',
	MAIL_PASSWORD='flvjttrlvnesbgjg')


class invalidMsg(Config):
	# 设置token失效密钥，后续放到配置文件中
	INVALID_KEY = 'secretKey'
	# 设置注册成功后token失效时间，后续放到配置文件中
	INVALID_TIME_REGISTER = 3600
	# 设置登录成功后token失效时间，后续放到配置文件中
	INVALID_TIME_LOGIN = 3600
 
 
# class TestingConfig(Config):
# 	TESTING = True