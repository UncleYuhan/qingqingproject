from models.user_list import userList
from models.user_login import userLogin
from models.user_register import userRegister
from flask_restful import reqparse, Resource
import time, random
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from mongoengine import *
from flask import current_app


# 引用配置文件中的设定值
# 设置token失效密钥
invalidKey = current_app.config["INVALID_KEY"]
# 设置注册成功后token失效时间
invalidtimeNew = current_app.config["INVALID_TIME_REGISTER"]
# 设置登录成功后token失效时间
invalidtime = current_app.config["INVALID_TIME_LOGIN"]


# 用户登录
class login(Resource):
    def get(self):
        pass
    def post(self):
        try:
            # 使用flask-restful获取请求的参数(账号、密码)
            parser = reqparse.RequestParser()
            parser.add_argument('name', type=str, location='headers', required=True,help="Name cannot be blank!")
            parser.add_argument('psd', type=str, location='headers', required=True,help="Password cannot be blank!")
            args = parser.parse_args()
            username = args['name']
            psd = args['psd']
            # 获取数据库中对应用户名的HSCODE
            try:
                getHsCode = userRegister.objects(Q(loginAccount=username))[0].psdHsCode
            except IndexError:
                return("账号不存在~")
            # 验证密码
            if check_password_hash(getHsCode, psd):
                # 验证通过后，生成token
                serializer = Serializer(invalidKey, invalidtime)
                userToken = serializer.dumps({"userName":username}).decode('utf-8')
                return(userToken)
            else:
                # 根据前端需求可调整返回内容
                return("密码错误")
        except NotUniqueError:
            return("其他错误？")
