from models.user_list import userList
from models.user_login import userLogin
from models.user_register import userRegister
from flask_restful import reqparse, Resource
import time, random
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from mongoengine import *
from flask import current_app


# 引用配置文件中的设定值
# 设置token失效密钥
invalidKey = current_app.config["INVALID_KEY"]
# 设置注册成功后token失效时间
invalidtimeNew = current_app.config["INVALID_TIME_REGISTER"]
# 设置登录成功后token失效时间
invalidtime = current_app.config["INVALID_TIME_LOGIN"]


# 注册用户
class register(Resource):
    def get(self):
        pass
    def post(self):
        # 使用flask-restful获取请求的参数(账号、密码)
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str, location='headers', required=True,help="Name cannot be blank!")
        parser.add_argument('psd', type=str, location='headers', required=True,help="Password cannot be blank!")
        parser.add_argument('yzm', type=str, location='headers', required=True,help="YZM cannot be blank!")
        args = parser.parse_args()
        loginaccount = args['name']
        password = args['psd']
        yzm = args['yzm']
        
        # No.1 新增一条Register数据
        # 使用werkzeug.security对密码进行加密
        psdhscode = generate_password_hash(password)
        # 时间存储，时间字符串/时间戳字符串
        # registertime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        registertime = str(time.time()) 
        # 给userRegister表插入数据，并判断用户名是否已存在
        try:
            addUserRegister = userRegister(
                loginAccount=loginaccount,
                psdHsCode=psdhscode,
                registerTime=registertime,
                mailVerificateCode=yzm).save()
        except NotUniqueError:
            return('the values already exist')

        # No.2 新增一条Login数据
        # 生成QUID(命名规则设定为：首字母‘Q’+8位时间部分+6位当日自然排序数+4位随机字符)
        # 首字母‘Q’+8位时间部分
        timeString = "Q" + time.strftime("%Y%m%d", time.localtime())
        # 生成6位当日自然排序数
        todayRightNew6 = str(len(userLogin.objects(quid__istartswith=timeString).only('quid'))+1).rjust(6,'0')
        # 生成4位随机字符
        random1 = random.sample('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',4)
        randomNew = ''.join(random1)
        # 生成最终的QUID
        newTodayQuid = timeString + todayRightNew6 + randomNew
        # 给userLogin表插入数据
        addUserLogin = userLogin(loginAccount=loginaccount, quid=newTodayQuid).save()

        # No.3 新增一条User数据
        # 给userList表插入数据
        addUserList = userList(
            quid=newTodayQuid,
            userName=loginaccount,
            sex='',
            location='',
            age='',
            qqNum='',
            wechatNum='',
            phoneNum='',
            qAuthority='',
            ifVip='',
            vipLevel='',
            userScore='',
            lastLoginTime='',
            imgUrl='',
            userDetail='',
            userHobby='',
            userJob='',
            userRole='',
            userEmail='').save()

        # No.4 注册成功生成的token
        # 生成token前的序列化，并预留失效时间（单位s）
        serializer = Serializer(invalidKey, invalidtimeNew)
        # 要加入token的信息
        addTokenInfoLoginAccount = {'userName':loginaccount}
        # 生成新token
        tokenNew = serializer.dumps(addTokenInfoLoginAccount).decode('utf-8')
        return(tokenNew)
