from flask import Flask, request, json, config
from flask_restful import reqparse, abort, Api, Resource
from flask_mail import Mail, Message


app = Flask(__name__)
api = Api(app)

# 推送应用上下文环境,让其他py中也能用到配置文件
app.app_context().push()
# 使用配置文件
# 配置数据库链接
app.config.from_object("settings.MongoDB")
# 配置用户token的密钥和失效时间
app.config.from_object("settings.invalidMsg")
# 配置发送邮件的邮箱参数
app.config.from_object("settings.MailMsg")


# 导入模块，配置路由
# 注册用户的模块导入和路由配置
from resources.register import register
api.add_resource(register, '/register')
# 修改密码的模块导入和路由配置
from resources.modify_password import modify_password
api.add_resource(modify_password, '/modify_password')
# 获取邮箱验证码的模块导入和路由配置
from resources.get_mailverificatecode import get_mailverificatecode, mail
mail.init_app(app)
api.add_resource(get_mailverificatecode, '/get_mailverificatecode')
# 获取密保方式的模块导入和路由配置
from resources.get_psdprotectway import get_psdprotectway
api.add_resource(get_psdprotectway, '/get_psdprotectway')
# 重置密码（需获取验证码）的模块导入和路由配置
from resources.reset_password import reset_password
api.add_resource(reset_password, '/reset_password')
# 设置密保邮箱的模块导入和路由配置
from resources.set_mailaccount import set_mailaccount
api.add_resource(set_mailaccount, '/set_mailaccount')
# 用户登录的模块导入和路由配置
from resources.login import login
api.add_resource(login, '/login')


if __name__ == '__main__':
    app.run(port=7777, debug=True)
