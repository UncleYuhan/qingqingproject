from flask import Flask
from mongoengine import *


class userRegister(Document):
    loginAccount = StringField(required = True, unique=True, max_length=50)
    psdHsCode = StringField(max_length = 255, unique=True, required = True)
    registerTime = StringField(max_length = 50, required = True)
    mailVerificateCode = StringField(max_length = 255, required = True)
    meta = {'allow_inheritance': True}
